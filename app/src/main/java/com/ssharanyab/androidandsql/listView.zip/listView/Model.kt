package com.hs1121.deligetsexample.listView

data class Model (var name:String,var age:Int)

public  class Mode(var name:String?=null,
var age:Int?=null)
